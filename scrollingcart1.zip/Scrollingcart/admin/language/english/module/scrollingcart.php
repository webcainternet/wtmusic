<?php
// Module Newsletter Subscription 
$_['heading_title']       = '<b style="color:red">Scrolling Cart </b>';
 
// Text
$_['text_module']         = 'Modules';
$_['text_edit']           = 'Edit Scrolling Cart Module';
$_['text_success']        = 'Success: You have modified module';
$_['text_yes']        	  = 'Yes';
$_['text_no']             = 'No';
$_['text_right']          = 'Right';
$_['text_left']           = 'Left';

$_['entry_js_status']     = 'Load JS library';
$_['entry_show_search']   = 'Display Search';
$_['entry_show_toplink']   = 'Display Back to Top link ';
$_['entry_show_cartposition']   = 'Select Scrolling cart Position';
$_['entry_bgcolor']   = 'Background Color';
$_['entry_delete_link']   = 'Display Delete Link';
$_['entry_price_color']   = 'Price Color';
$_['entry_product_name_color']   = 'Product Name Color';
// Entry
$_['entry_status']        = 'Enable';
// Error
$_['error_permission']    = 'Warning: You do not have permission to modify module Scrolling Cart!';
$_['error_code']          = 'Code Required'; 
$_['error_name']          = 'This is a required field';
