<?php
// Heading 
$_['heading_title']    = 'Scrolling Cart';
$_['text_items']     = '%s item(s) - %s';
$_['text_empty']     = 'Your shopping cart is empty!';
$_['text_cart']      = 'View Cart';
$_['text_checkout']  = 'Checkout';
$_['text_recurring'] = 'Payment Profile';
$_['text_items_count']     = '%s';
$_['text_total']     = '%s';
$_['text_no_item']           = 'You have no items in your shopping cart.';
$_['text_cart_total']           = 'Cart Total:';
?>
