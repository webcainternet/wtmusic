<?php
// Text
$_['text_success']     = ' Você modificou seu carrinho de compras com sucesso!';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para acessar a API!';
$_['error_stock']      = 'Os produtos marcados com *** não estão disponíveis na quantidade desejada ou não em estoque!';
$_['error_minimum']    = 'O montante mínimo de ordem para %s é %s!';
$_['error_store']      = 'O produto não pode ser comprado na loja que você criou!';
$_['error_required']   = '%s necessário!';