<?php
// Text
$_['text_success'] = 'Sucesso: sessão API iniciado com êxito!';

// Error
$_['error_login']  = 'Atenção: E-mail e ou senha inválido(s).';