<?php
// Text
$_['text_success']     = 'O seu cupom de desconto foi aplicado com sucesso!';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para acessar a API!';
$_['error_coupon']     = 'Aviso: Cupom é inválido, expirou ou atingiu o limite de it\'s uso!';