<?php
// Text
$_['text_success']     = 'Seus pontos de recompensa de desconto foi aplicado com sucesso!';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para acessar a API!';
$_['error_reward']     = 'Atenção: Por favor, insira a quantidade de pontos de recompensa para usar!';
$_['error_points']     = 'Atenção: Você não \ tem pontos de recompensa!';
$_['error_maximum']    = 'Atenção: O número máximo de pontos que pode ser aplicada é %s!';