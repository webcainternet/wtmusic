<?php
// Text
$_['text_success']       = 'Cliente modificado com sucesso!';

// Error
$_['error_permission']   = 'Atenção: Você não tem permissão para acessar a API!';
$_['error_firstname']    = 'O nome deve ter entre 1 e 32 caracteres!';
$_['error_lastname']     = 'O sobrenome deve ter entre 1 e 32 caracteres!';
$_['error_email']        = 'E-mail inválido!';
$_['error_telephone']    = 'O telefone deve ter entre 3 e 32 caracteres!';
$_['error_custom_field'] = '%s necessário!';