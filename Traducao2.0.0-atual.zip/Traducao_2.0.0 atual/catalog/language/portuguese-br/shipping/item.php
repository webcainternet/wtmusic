<?php
// Text
$_['text_title']       = 'Por Item';
$_['text_description'] = 'Taxa de envio por item';