<?php
// Text
$_['text_title']  = 'Peso base';
$_['text_weight'] = 'Peso:';