<?php
// Heading
$_['heading_title'] = 'Use seus pontos de fidelidade (disponível %s)';

// Text
$_['text_success']  = 'Seus pontos de fidelidade foram aplicados com sucesso!';

// Entry
$_['entry_reward']  = 'Pontos de fidelidade para usar (Max %s)';

// Error
$_['error_reward']  = 'Atenção: Por favor digite quantos pontos deseja usar!';
$_['error_points']  = 'Atenção: Você não tem %s pontos de fidelidade!';
$_['error_maximum'] = 'Atenção: O máximo de pontos de fidelidade que podem ser aplicados é %s!';