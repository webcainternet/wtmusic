<?php
// Heading
$_['heading_title'] = 'Use Cupom de Desconto';

// Text
$_['text_success']  = 'Seu cupom de desconto foi aplicado com sucesso!';

// Entry
$_['entry_coupon']  = 'Digite seu cupom aqui';

// Error
$_['error_coupon']  = 'Atenção: O cupom é inválido, expirou ou atingiu o seu limite de uso!';
$_['error_empty']   = 'Atenção: Por favor digite o código do cupom!';