<?php
// Heading
$_['heading_title'] = 'Use seu vale presente';

// Text
$_['text_success']  = 'Seu vale presente foi aplicado com sucesso!';

// Entry
$_['entry_voucher'] = 'Digite o código do seu vale presente aqui';

// Error
$_['error_voucher'] = 'Atenção: Vale presente é inválido, expirou ou atingiu o seu limite de uso!';
$_['error_empty']   = 'Atenção: Digite o código do seu vale presente!';