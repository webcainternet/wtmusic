<?php
// Text
$_['text_total_shipping']		= 'Envio';
$_['text_total_discount']		= 'Desconto';
$_['text_total_tax']			= 'Tax';
$_['text_total_sub']			= 'Sub-total';
$_['text_total']				= 'Total';