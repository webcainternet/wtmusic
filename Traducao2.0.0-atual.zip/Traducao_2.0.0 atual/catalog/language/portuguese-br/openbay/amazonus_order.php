<?php
// Text
$_['text_paid_amazon'] 			= 'Pago na Amazon dos EUA';
$_['text_total_shipping'] 		= 'Envio';
$_['text_total_shipping_tax'] 	= 'Imposto de envio';
$_['text_total_giftwrap'] 		= 'Embrulho';
$_['text_total_giftwrap_tax'] 	= 'Embrulho fiscal';
$_['text_total_sub'] 			= 'Sub-total';
$_['text_tax'] 					= 'Tax';
$_['text_total'] 				= 'Total';