<?php
// Heading
$_['heading_title']    = 'Afiliado';

// Text
$_['text_register']    = 'Cadastrar';
$_['text_login']       = 'Acessar';
$_['text_logout']      = 'Sair';
$_['text_forgotten']   = 'Esqueceu a Senha?';
$_['text_account']     = 'Painel de Afiliado';
$_['text_edit']        = 'Alterar Informações';
$_['text_password']    = 'Alterar Senha';
$_['text_payment']     = 'Como Receber?';
$_['text_tracking']    = 'Gerar Links';
$_['text_transaction'] = 'Minhas Indicações';
