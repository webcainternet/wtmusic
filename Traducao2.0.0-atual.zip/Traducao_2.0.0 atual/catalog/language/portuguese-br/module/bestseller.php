<?php
// Heading
$_['heading_title'] = 'Mais Vendidos';

// Text
$_['text_tax']      = 'Ex Tax:';