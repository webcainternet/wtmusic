<?php
// Heading
$_['heading_title'] = 'Especiais';

// Text
$_['text_tax']      = 'Ex Tax:';