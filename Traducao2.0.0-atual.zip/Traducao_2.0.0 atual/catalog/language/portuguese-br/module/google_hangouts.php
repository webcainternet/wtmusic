<?php
// Heading
$_['heading_title']  = 'Atendimento ao Vivo';