<?php
// Text
$_['text_upload']    = 'Seu upload foi feito com sucesso!';

// Error
$_['error_filename'] = 'O nome do arquivo deve ter entre 3 e 64 caracteres!';
$_['error_filetype'] = 'Tipo de arquivo inválido!';
$_['error_upload']   = 'Upload obrigatório!';
