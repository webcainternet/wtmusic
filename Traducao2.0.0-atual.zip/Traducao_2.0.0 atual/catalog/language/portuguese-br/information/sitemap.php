<?php
// Heading
$_['heading_title']    = 'Mapa da Loja';
 
// Text
$_['text_special']     = 'Ofertas Especiais';
$_['text_account']     = 'Minha Conta';
$_['text_edit']        = 'Informações da Conta';
$_['text_password']    = 'Alterar Senha';
$_['text_address']     = 'Lista de Endereços';
$_['text_history']     = 'Histórico de Pedidos';
$_['text_download']    = 'Meus Downloads';
$_['text_cart']        = 'Meu Carrinho';
$_['text_checkout']    = 'Finalizar Compra';
$_['text_search']      = 'Buscar por Produtos';
$_['text_information'] = 'Informações';
$_['text_contact']     = 'Contate-nos';