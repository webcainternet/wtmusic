<?php
// Text
$_['text_error'] = 'A página solicitada não foi encontrada!';