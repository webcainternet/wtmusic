<?php
// Text
$_['text_information']  = 'Informações';
$_['text_service']      = 'Atendimento';
$_['text_extra']        = 'Extras';
$_['text_contact']      = 'Contate-nos';
$_['text_return']       = 'Devoluções';
$_['text_sitemap']      = 'Mapa da Loja';
$_['text_manufacturer'] = 'Lista de Fabricantes';
$_['text_voucher']      = 'Comprar Vale Presente';
$_['text_affiliate']    = 'Programa de Afiliados';
$_['text_special']      = 'Especiais';
$_['text_account']      = 'Minha Conta';
$_['text_order']        = 'Histórico de Pedidos';
$_['text_wishlist']     = 'Lista de Desejos';
$_['text_newsletter']   = 'Meu Informativo';
$_['text_powered']      = 'Criado com <a href="http://www.opencart.com">OpenCart</a><br /> %s &copy; %s';