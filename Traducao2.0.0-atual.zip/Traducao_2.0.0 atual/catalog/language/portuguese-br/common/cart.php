<?php
// Text
$_['text_items']    = '%s item(s) - %s';
$_['text_empty']    = 'Seu carrinho está vazio!';
$_['text_cart']     = 'Ver Carrinho';
$_['text_checkout'] = 'Finalizar';
$_['text_recurring']  = 'Perfil de Pagamento';