<?php
// Text
$_['text_home']          = 'Principal';
$_['text_wishlist']      = 'Lista de Desejos (%s)';
$_['text_shopping_cart'] = 'Meu Carrinho';
$_['text_category']      = 'Categori';
$_['text_account']       = 'Minha Conta';
$_['text_register']      = 'Cadastrar';
$_['text_login']         = 'Logar';
$_['text_order']         = 'Histórico de pedidos';
$_['text_transaction']   = 'Transações';
$_['text_download']      = 'Downloads';
$_['text_logout']        = 'Sair';
$_['text_checkout']      = 'Finalizar Pedido';
$_['text_search']        = 'Buscar Produto';
$_['text_all']           = 'Ver Todos';