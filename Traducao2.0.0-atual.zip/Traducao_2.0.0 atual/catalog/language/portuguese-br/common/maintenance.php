<?php
// Heading
$_['heading_title']    = 'Manutenção';

// Text
$_['text_maintenance'] = 'Manutenção';
$_['text_message']     = '<h1 style="text-align:center;">No momento, estamos realizando alguma manutenção programada. <br/>Estaremos de volta o mais rápido possível. Por favor, volte em breve.</h1>';