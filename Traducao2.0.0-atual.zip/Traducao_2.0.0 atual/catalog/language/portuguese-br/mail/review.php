<?php
// Text
$_['text_subject']	= '%s - Comentários de produto';
$_['text_waiting']	= 'Você tem um novo comentário aguardando.';
$_['text_product']	= 'Produto: %s';
$_['text_reviewer']	= 'Avaliador: %s';
$_['text_rating']	= 'Avaliação: %s';
$_['text_review']	= 'Comentário:';