<?php
// Heading
$_['heading_title'] = 'Sair da Minha Conta';

// Text
$_['text_message']  = '<p>Você saiu de sua conta. Agora você pode sair da loja de maneira segura.</p><p>Se havia itens em seu carrinho eles foram salvos e serão recuperados quando você efetuar o acesso novamente.</p>';
$_['text_account']  = 'Minha Conta';
$_['text_logout']   = 'Sair';