<?php
// Heading
$_['heading_title']    = 'Meu Informativo';

// Text
$_['text_account']     = 'Minha Conta';
$_['text_newsletter']  = 'Meu Informativo';
$_['text_success']     = 'Inscrição no informativo atualizada com sucesso!';

// Entry
$_['entry_newsletter'] = 'Receber o Informativo:';
