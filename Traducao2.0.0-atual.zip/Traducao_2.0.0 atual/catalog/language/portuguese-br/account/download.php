<?php
// Heading
$_['heading_title']   = 'Meus Downloads';

// Text
$_['text_account']    = 'Minha Conta';
$_['text_downloads']  = 'Downloads';
$_['text_empty']      = 'Nenhum pedido de download foi registrado até o momento!';

// Column
$_['column_order_id']   = 'Pedido ID';
$_['column_name']       = 'Nome';
$_['column_size']       = 'Tamanho';
$_['column_date_added'] = 'Adicionado em';