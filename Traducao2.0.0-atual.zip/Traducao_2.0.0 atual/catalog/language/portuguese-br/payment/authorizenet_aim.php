<?php
// Text
$_['text_title']				= 'Cartão de Crédito / Cartão de Débito (Authorize.Net)';
$_['text_credit_card']			= 'Detalhes do cartão de crédito';

// Entry
$_['entry_cc_owner']			= 'O cartão do proprietário';
$_['entry_cc_number']			= 'Número do cartão';
$_['entry_cc_expire_date']		= 'Data de validade do cartão';
$_['entry_cc_cvv2']				= 'Código de Segurança do Cartão (CVV2)';