<?php
// Text
$_['text_title']				= 'Crédito ou Débito';
$_['text_secure_connection']	= 'Criando uma conexão segura...';

// Error
$_['error_connection']			= 'Não foi possível conectar ao PayPal. Por favor, entre em contato com o \ administrator para obter assistência ou escolha um método de pagamento diferente.';