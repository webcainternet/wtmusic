<?php
// Text
$_['text_title']				= 'PayPal';
$_['text_reason']				= 'Razão';
$_['text_testmode']				= 'Atenção: O Gateway de Pagamento está em \"Modo de Teste\". Sua conta não será cobrada.';
$_['text_total']				= 'Transporte, manuseio, descontos e impostos';