<?php
// Text
$_['text_title']				= 'Cartão de Crédito ou Cartão de débito';
$_['text_secure_connection']	= 'Criando uma conexão segura...';

// Error
$_['error_connection']			= 'Não foi possível conectar a PayPa. Por favor, Entre em contato com o \  administrador para obter assistência ou escolha um método de pagamento diferente.';