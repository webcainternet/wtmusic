<?php
// Text
$_['text_title'] = 'Cartão de Crédito / Cartão de Débito (Authorize.Net)';