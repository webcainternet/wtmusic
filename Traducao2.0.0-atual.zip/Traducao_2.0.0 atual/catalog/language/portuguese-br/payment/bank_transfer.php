<?php
// Text
$_['text_title']				= 'Depósito ou Transferência Bancária';
$_['text_instruction']			= 'Instruções para o pagamento por depósito ou transferência bancária.';
$_['text_payment']				= 'Seu pedido não será enviado até que recebamos o pagamento.';