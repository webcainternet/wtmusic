<?php
// Heading
$_['heading_title']		= 'Formas de Pagamento';

// Text
$_['text_success']      = 'Forma de pagamento modificada com sucesso!';
$_['text_list']         = 'Lista de formas de pagamento';

// Column
$_['column_name']		= 'Forma de Pagamento';
$_['column_status']		= 'Situação';
$_['column_sort_order']	= 'Ordem de Exibição';
$_['column_action']		= 'Ação';

// Error
$_['error_permission']  = 'Atenção: Você não tem permissão para modificar as formas de pagamento!';