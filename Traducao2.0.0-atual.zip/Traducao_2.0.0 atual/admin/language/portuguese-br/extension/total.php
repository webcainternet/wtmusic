<?php
// Heading
$_['heading_title']		= 'Finalização do Pedido';

// Text
$_['text_success']      = 'Pedido Modificado com sucesso!';
$_['text_list']         = 'Lista de Pedidos';

// Column
$_['column_name']		= 'Recurso de Finalização';
$_['column_status']		= 'Situação';
$_['column_sort_order']	= 'Ordem de Exibição';
$_['column_action']		= 'Ação';

// Error
$_['error_permission']  = 'Atenção: Você não tem permissão para modificar a finalização do pedido!';