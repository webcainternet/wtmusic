<?php
// Heading
$_['heading_title']		= 'Formas de Envio';

// Text
$_['text_success']      = 'Forma de envio modificado com sucesso!';
$_['text_list']         = 'Lista de formas de envio';

// Column
$_['column_name']		= 'Forma de Envio';
$_['column_status']		= 'Situação';
$_['column_sort_order']	= 'Ordem de Exibição';
$_['column_action']		= 'Ação';

// Error
$_['error_permission']  = 'Atenção: Você não tem permissão para modificar as formas de envio!';