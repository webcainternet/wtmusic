<?php
// Heading
$_['heading_title']	   = 'Feed de Produtos';

// Text
$_['text_success']     = 'Feed modificado com sucesso!';
$_['text_list']        = 'Lista de Feed';


// Column
$_['column_name']	   = 'Feed';
$_['column_status']	   = 'Situação';
$_['column_action']	   = 'Ação';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar os feeds de produtos!';