<?php
// Heading
$_['heading_title']	   = 'Módulos';

// Text
$_['text_success']     = 'Módulo modificado com sucesso.';
$_['text_layout']      = 'Depois de configurar e instalar um módulo, você pode adicionar a um layout <a href="%s" class="alert-link">aqui</a>!';
$_['text_list']        = 'Lista de módulos';

// Column
$_['column_name']	   = 'Módulo';
$_['column_action']	   = 'Ação';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar os módulos!';