<?php
// Heading
$_['heading_title']     = 'HTML Conteúdo';

// Text
$_['text_module']       = 'Modules';
$_['text_success']      = 'Você modificou HTML Conteúdo com sucesso!';
$_['text_edit']         = 'Editar HTML Conteúdo';

// Entry
$_['entry_heading']     = 'Cabeçalho título';
$_['entry_description'] = 'Conteúdo';
$_['entry_status']      = 'Situação';

// Error
$_['error_permission']  = 'Atenção: Você não tem permissão para modificar HTML Conteúdo módulo!';