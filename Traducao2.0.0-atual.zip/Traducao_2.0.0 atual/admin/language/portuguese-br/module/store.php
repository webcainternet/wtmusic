<?php
// Heading
$_['heading_title']       = 'Seleção de Loja';

// Text
$_['text_module']         = 'Módulos';
$_['text_success']        = 'Módulo Seleção de Loja modificado com sucesso!';
$_['text_edit']        = 'Editar Módulo';

// Entry
$_['entry_admin']         = 'Acesso somente para administradores:';
$_['entry_status']        = 'Situação:';

// Error
$_['error_permission']    = 'Atenção: Você não possui permissão para modificar o módulo Seleção de Loja!';
