<?php
// Heading
$_['heading_title']    = 'Filtros';

// Text
$_['text_module']      = 'Módulos';
$_['text_success']     = 'Módulo Filtros modificado com sucesso!';
$_['text_edit']        = 'Editar Módulo Filtros';

// Entry
$_['entry_status']     = 'Situação';

// Error
$_['error_permission'] = 'Atenção: Você não possui permissão para modificar o módulo Filtros!';