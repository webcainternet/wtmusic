<?php
// Heading
$_['heading_title']    = 'Pagamentos Amazon Button';

$_['text_module']      = 'Módulos';
$_['text_success']     = 'Você modificou o módulo pagamentos Amazon com sucesso!';
$_['text_edit']        = 'Editar módulo pagamentos Amazon';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar módulo pagamentos Amazon!';