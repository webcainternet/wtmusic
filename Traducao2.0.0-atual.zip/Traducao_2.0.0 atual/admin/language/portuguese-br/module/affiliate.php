<?php
// Heading
$_['heading_title']       = 'Menu de Afiliados';

$_['text_module']         = 'Módulos';
$_['text_success']        = 'Módulo Menu de Afiliados modificado com sucesso!';
$_['text_edit']        = 'Editar Afiliados';

// Entry
$_['entry_status']        = 'Situação:';

// Error
$_['error_permission']    = 'Atenção: Você não possui permissão para modificar módulo Menu de Afiliados!';
