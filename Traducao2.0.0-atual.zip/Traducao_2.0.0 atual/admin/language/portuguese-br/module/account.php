<?php
// Heading
$_['heading_title']       = 'Menu de Contas';

// Text
$_['text_module']         = 'Módulos';
$_['text_success']        = 'Módulo Menu de Contas modificado com sucesso!';
$_['text_edit']        = 'Editar Contas';

// Entry
$_['entry_status']        = 'Situação:';

// Error
$_['error_permission']    = 'Atenção: Você não possui permissão para modificar o módulo Menu de Contas!';
