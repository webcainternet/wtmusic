<?php
// Heading
$_['heading_title']       = 'Menu Categorias'; 

// Text
$_['text_module']         = 'Módulos';
$_['text_success']        = 'Módulo Menu Categorias modificado com sucesso!';
$_['text_edit']        = 'Editar Categorias';

// Entry
$_['entry_status']        = 'Situação:';

// Error
$_['error_permission']    = 'Atenção: Você não possui permissão para modificar o módulo Menu Departamentos!';
