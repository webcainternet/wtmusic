<?php
// Heading
$_['heading_title']    = 'PayPal Express Checkout Button';

// Text
$_['text_module']      = 'Módulos';
$_['text_success']     = 'Você modificou módulo Botão PayPal Express Checkout com sucesso!';
$_['text_edit']        = 'Editar PayPal Express Checkout Module Button';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar módulo Botão PayPal Express Checkout!';