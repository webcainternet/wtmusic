<?php
// Heading
$_['heading_title']	  = 'OpenBay Pro';

// Text
$_['text_module']    = 'Modules';
$_['text_installed'] = 'OpenBay está instalado. disponível em extensões -> OpenBay Pro';