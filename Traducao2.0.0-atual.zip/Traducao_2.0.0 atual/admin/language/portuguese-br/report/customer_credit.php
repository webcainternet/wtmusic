<?php
// Heading
$_['heading_title']         = 'Relatório de Crédito por Cliente';

// Column
$_['text_list']             = 'Listar Crédito por Cliente';
$_['column_customer']       = 'Cliente';
$_['column_email']          = 'E-mail';
$_['column_customer_group'] = 'Grupo de Clientes';
$_['column_status']         = 'Situação';
$_['column_total']          = 'Total';
$_['column_action']         = 'Ação';

// Entry
$_['entry_date_start']      = 'Data do Início:';
$_['entry_date_end']        = 'Data do Fim:';