<?php
// Heading
$_['heading_title']     = 'Relatório de Clientes Online';

// Text
$_['text_list']         = 'Listar Clientes Online';
$_['text_guest']        = 'Visitante';
 
// Column
$_['column_ip']         = 'IP';
$_['column_customer']   = 'Cliente';
$_['column_url']        = 'Última Página Visitada';
$_['column_referer']    = 'Referência';
$_['column_date_added'] = 'Último Acesso';
$_['column_action']     = 'Ação';

// Entry
$_['entry_ip']          = 'IP';
$_['entry_customer']    = 'Cliente';