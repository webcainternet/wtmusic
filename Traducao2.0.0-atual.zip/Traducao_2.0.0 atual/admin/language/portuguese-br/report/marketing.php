<?php
// Heading
$_['heading_title']    = 'Relatório de Marketing';

// Text
$_['text_list']         = 'Listar Relatório de Marketing';
$_['text_all_status']   = 'Situações';

// Column
$_['column_campaign']  = 'Nome da campanha';
$_['column_code']      = 'Código';
$_['column_clicks']    = 'Cliques';
$_['column_orders']    = 'Não tem pedidos';
$_['column_total']     = 'Total';

// Entry
$_['entry_date_start'] = 'Data Início';
$_['entry_date_end']   = 'Data Final';
$_['entry_status']     = 'Situação do pedido';