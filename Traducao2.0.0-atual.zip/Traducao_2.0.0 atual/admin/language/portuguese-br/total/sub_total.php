<?php
// Heading
$_['heading_title']    = 'Sub-Total';

// Text
$_['text_total']       = 'Finalização do Pedido';
$_['text_success']     = 'SMódulo Sub-Total modificado com sucesso!';
$_['text_edit']        = 'Editar Módulo Sub-Total';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Ordem';

// Error
$_['error_permission'] = 'Atenção: Você não possui permissão para modificar o módulo Sub-Total!';