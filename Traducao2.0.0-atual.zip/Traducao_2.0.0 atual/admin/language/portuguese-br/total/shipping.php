<?php
// Heading
$_['heading_title']    = 'Simular Frete';

// Text
$_['text_total']       = 'Finalização do Pedido';
$_['text_success']     = 'Módulo Frete modificado com sucesso!';
$_['text_edit']        = 'Edita Módulo Simular Frete';

// Entry
$_['entry_estimator']  = 'Simular Frete';
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Ordem';

// Error
$_['error_permission'] = 'Atenção: Você não possui permissão para modificar o módulo Frete!';