<?php
// Heading
$_['heading_title']    = 'Cupom';

// Text
$_['text_total']       = 'Pedidos Totais';
$_['text_success']     = 'Você modificou cupom total com sucesso!';
$_['text_edit']        = 'Editar Cupom';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Pedido';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar cupom total !';