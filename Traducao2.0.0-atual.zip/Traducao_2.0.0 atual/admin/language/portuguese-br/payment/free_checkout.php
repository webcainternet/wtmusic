<?php
// Heading
$_['heading_title']		 = 'Frete Grátis';

// Text
$_['text_payment']		 = 'Pagamento';
$_['text_success']		 = 'Sucesso: Você modificou o módulo de pagamento Checkout Grátis!';
$_['text_edit']          = 'Editar Frete Grátis';

// Entry
$_['entry_order_status'] = 'Situação do pedido';
$_['entry_status']		 = 'Situação';
$_['entry_sort_order']	 = 'Ordem';

// Error
$_['error_permission']	  = 'Aviso: Você não tem permissão para modificar o módulo Frete Grátis!';