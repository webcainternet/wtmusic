<?php
// Heading
$_['heading_title']					= 'Restituição da Transação';

// Text
$_['text_pp_express']				= 'PayPal Express Checkout';
$_['text_current_refunds']			= 'As restituições já foram feitas para esta transação. O reembolso máximo é';

// Entry
$_['entry_transaction_id']			= 'ID da Transação';
$_['entry_full_refund']				= 'Reembolso Integral';
$_['entry_amount']					= 'Valor';
$_['entry_message']					= 'Mensagem';

// Button
$_['button_refund']					= 'Motivos do Reembolso';

// Error
$_['error_partial_amt']				= 'Você deve digitar um valor de reembolso parcial';
$_['error_data']					= 'Esta faltando dados do pedido';