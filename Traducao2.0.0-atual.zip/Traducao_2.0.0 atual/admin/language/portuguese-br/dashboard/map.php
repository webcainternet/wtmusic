<?php
// Heading
$_['heading_title'] = 'Mapa Mundial';

$_['text_order']    = 'Pedidos';
$_['text_sale']     = 'Vendas';