<?php
// Heading
$_['heading_title']     = 'Últimos pedidos';

// Column
$_['column_order_id']   = 'Pedido ID';
$_['column_customer']   = 'Cliente';
$_['column_status']     = 'Situação';
$_['column_total']      = 'Total';
$_['column_date_added'] = 'Adicionado em';
$_['column_action']     = 'Ação';