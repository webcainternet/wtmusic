<?php
// Heading
$_['heading_title'] = 'Análise de vendas';

// Text
$_['text_order']    = 'Pedidos';
$_['text_customer'] = 'Clientes';
$_['text_day']      = 'Hoje';
$_['text_week']     = 'Semana';
$_['text_month']    = 'Mês';
$_['text_year']     = 'Ano';