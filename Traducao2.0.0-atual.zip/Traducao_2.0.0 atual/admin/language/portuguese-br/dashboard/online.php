<?php
// Heading
$_['heading_title'] = 'Clientes Online';

// Text
$_['text_view']     = 'Veja mais...';