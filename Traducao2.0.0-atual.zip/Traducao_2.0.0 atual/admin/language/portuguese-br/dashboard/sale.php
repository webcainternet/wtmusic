d<?php
// Heading
$_['heading_title'] = 'Total de Vendas';

// Text
$_['text_view']     = 'Veja mais...';