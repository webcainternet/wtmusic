<?php
// Heading
$_['heading_title']     = 'Uploads';

// Text
$_['text_success']      = 'Uploads modificado com sucesso!';
$_['text_list']         = 'Lista de Uploads';

// Column
$_['column_name']       = 'Nome Upload';
$_['column_filename']   = 'Nome do Arquivo';
$_['column_date_added'] = 'Adicionado em';
$_['column_action']     = 'Ação';

// Entry
$_['entry_name']        = 'Nome Upload';
$_['entry_filename']    = 'Nome do Arquivo';
$_['entry_date_added'] 	= 'Adicionado em';

// Error
$_['error_permission']  = 'Atenção: Você não tem permissão para modificar uploads!';