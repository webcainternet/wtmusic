<?php
// Heading
$_['heading_title'] = 'Logs de Erros';

// Text
$_['text_success']  = 'Logs de erros apagados com sucesso!';
$_['text_list']        = 'Lista de Erros';

// Error
$_['error_warning']	   = 'Atenção: Seu arquivo de log %s está %s!';
$_['error_permission'] = 'Atenção: Você não tem acesso ao log!';