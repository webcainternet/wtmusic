<?php
// Text
$_['text_subject']  = 'Você recebeu um vale presentes de %s';
$_['text_greeting'] = 'Parabéns! Você acaba de receber um vale presentes de %s';
$_['text_from']     = 'Quem lhe enviou este vale presentes foi %s';
$_['text_message']  = 'Com a seguinte mensagem:';
$_['text_redeem']   = 'Para utilizar este vale presentes anote o código: <b>%s</b>.<br />Agora clique no link abaixo e faça a compra dos produtos que você desejar!<br /><b>Importante:</b> Se o valor total do seu pedido ultrapassar o valor do vale presentes que você recebeu, você poderá pagar a diferença do valor excedido diretamente na loja.<br />Para utilizar o seu vale presentes, você deve inserir o código dele na página do seu carrinho de compras antes mesmo de finalizar o pedido.';
$_['text_footer']   = 'Caso tenha alguma dúvida responda este e-mail.';