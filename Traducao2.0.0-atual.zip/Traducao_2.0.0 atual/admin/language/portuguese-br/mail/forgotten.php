<?php
// Text
$_['text_subject']  = '%s - Solicitação de redefinição de senha';
$_['text_greeting'] = 'Foi solicitada a redefinição de senha para administração da loja %s.';
$_['text_change']   = 'Para recadastrar sua senha, clique no link abaixo:';
$_['text_ip']       = 'O IP utilizado para fazer esta solicitação foi: %s';