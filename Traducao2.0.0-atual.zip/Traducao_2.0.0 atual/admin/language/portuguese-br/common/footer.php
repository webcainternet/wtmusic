<?php
// Text
$_['text_footer'] 	= '<a href="#" target="_blank">Opencart</a>  ' . date('Y') . ' Todos os direitos reservados.';
$_['text_version'] 	= 'Version %s';