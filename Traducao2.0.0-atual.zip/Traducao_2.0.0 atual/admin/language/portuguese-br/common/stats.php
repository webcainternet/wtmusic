<?php
$_['text_complete_status']   = 'Pedidos Confirmados'; 
$_['text_processing_status'] = 'Pedidos em Processo'; 
$_['text_other_status']      = 'Outras Situações'; 