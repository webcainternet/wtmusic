<?php
// Heading
$_['heading_title']    = 'Pinterest Profile Widget';

// Text
$_['text_edit']        = 'Edit Account';
